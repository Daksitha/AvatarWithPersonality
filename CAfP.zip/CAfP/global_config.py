gui_status = "ACTIVE_SESSION"
gui_err_msg = ""
IMPORT_DATA= False
BONE_PARAMETERS_JSON = {}

